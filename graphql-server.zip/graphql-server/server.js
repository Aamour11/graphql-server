const express = require('express');
const { graphqlHTTP } = require('express-graphql');
const { buildSchema } = require('graphql');
const cors = require('cors');

// Dummy data storage for bookshelves
let bookshelves = [
  { id: '1', name: 'Fiction Shelf', capacity: 20, location: 'First Floor' },
  { id: '2', name: 'Science Shelf', capacity: 15, location: 'Second Floor' }
];

// 1. Define Schema
const schema = buildSchema(`
  type Bookshelf {
    id: ID!
    name: String!
    capacity: Int!
    location: String!
  }

  type Query {
    bookshelves: [Bookshelf]
    bookshelf(id: ID!): Bookshelf
  }

  type Mutation {
    createBookshelf(name: String!, capacity: Int!, location: String!): Bookshelf
    updateBookshelf(id: ID!, name: String!, capacity: Int!, location: String!): Bookshelf
    deleteBookshelf(id: ID!): Boolean
  }
`);

// 2. Define Resolvers
const root = {
  bookshelves: () => bookshelves,
  bookshelf: ({ id }) => bookshelves.find(shelf => shelf.id === id),
  createBookshelf: ({ name, capacity, location }) => {
    const bookshelf = {
      id: String(bookshelves.length + 1),
      name,
      capacity,
      location
    };
    bookshelves.push(bookshelf);
    return bookshelf;
  },
  updateBookshelf: ({ id, name, capacity, location }) => {
    const shelfIndex = bookshelves.findIndex(shelf => shelf.id === id);
    if (shelfIndex === -1) return null;
    
    bookshelves[shelfIndex] = {
      ...bookshelves[shelfIndex],
      name,
      capacity,
      location
    };
    return bookshelves[shelfIndex];
  },
  deleteBookshelf: ({ id }) => {
    const shelfIndex = bookshelves.findIndex(shelf => shelf.id === id);
    if (shelfIndex === -1) return false;
    
    bookshelves = bookshelves.filter(shelf => shelf.id !== id);
    return true;
  }
};

// 3. Setup Express Server
const app = express();
app.use(cors()); // Enable CORS
app.use(express.static('public')); // Serve static files

app.use('/graphql', graphqlHTTP({
  schema: schema,
  rootValue: root,
  graphiql: true,
}));

app.listen(4000, () => {
  console.log('Server running at http://localhost:4000/graphql');
});
